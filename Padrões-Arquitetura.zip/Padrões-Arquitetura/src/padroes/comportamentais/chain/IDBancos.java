package padroes.comportamentais.chain;

public enum IDBancos {
	bancoA, bancoB, bancoC, bancoD 
}
